import JSZip from 'jszip';
import './style.css';

const app = document.querySelector('#app');
app.innerHTML = `
<div class="shell">
  <aside class="sidebar">
    <div class="brand"><div class="brand-icon">✦</div><div><b>Addon AI 3D</b><small>STUDIO • BEDROCK</small></div></div>
    <div class="nav-label">WORKSPACE</div>
    <div class="nav active">✧ <span>Criar addon</span></div>
    <div class="nav">▦ <span>Meus projetos</span><em>Em breve</em></div>
    <div class="nav">◇ <span>Biblioteca 3D</span><em>Em breve</em></div>
    <div class="sidebar-bottom"><div class="status-dot"></div><span>Gerador local ativo</span></div>
  </aside>
  <main>
    <header><div><div class="eyebrow">MINECRAFT BEDROCK CREATOR</div><h1>Transforme ideias em <span>addons 3D.</span></h1><p>Descreva sua criação. Gere os arquivos e baixe o pacote para testar no Minecraft.</p></div><div class="version-pill">MVP <b>0.1</b></div></header>
    <section class="workspace">
      <div class="panel prompt-panel">
        <div class="panel-heading"><div><span class="step">01</span><h2>Descreva sua ideia</h2></div><span class="tiny-tag">PROMPT</span></div>
        <label for="description">O que você quer criar?</label>
        <textarea id="description" rows="5" placeholder="Ex.: Crie um dragão azul que voa, com olhos brilhantes e animação de movimento.">Crie um dragão azul com olhos brilhantes e animação de movimento.</textarea>
        <div class="suggestions"><button class="suggestion" data-prompt="Crie um dragão vermelho com asas e olhos brilhantes.">🐉 Dragão</button><button class="suggestion" data-prompt="Crie um robô guardião metálico com detalhes azuis.">🤖 Robô</button><button class="suggestion" data-prompt="Crie uma máquina industrial verde com luzes e partes metálicas.">⚙️ Máquina</button></div>
        <div class="options">
          <div><label for="kind">Tipo de addon</label><select id="kind"><option value="entity">Criatura / entidade 3D</option><option value="machine">Máquina decorativa</option><option value="item">Item simples</option></select></div>
          <div><label for="target">Edição / plataforma</label><select id="target"><option value="bedrock">Bedrock (.mcaddon)</option><option value="java-fabric">Java — Fabric (projeto ZIP)</option><option value="java-neoforge">Java — NeoForge (projeto ZIP)</option></select></div>
        </div>
        <button id="generate" class="primary"><span>✧</span> Gerar addon</button>
        <p class="disclaimer">Modo IA conectado: interpreta sua ideia por um serviço de IA quando a chave do servidor estiver configurada. Sem configuração, usa o gerador local.</p>
      </div>
      <div class="panel preview-panel">
        <div class="panel-heading"><div><span class="step">02</span><h2>Prévia do projeto</h2></div><span class="live"><i></i> PRONTO PARA GERAR</span></div>
        <div class="preview-stage"><div class="grid-floor"></div><div id="model" class="cube-model"><div class="cube-body"></div><div class="cube-head"></div><div class="cube-wing left"></div><div class="cube-wing right"></div><div class="cube-leg one"></div><div class="cube-leg two"></div><div class="eye e1"></div><div class="eye e2"></div></div><div class="stage-caption"><b id="preview-name">Dragão Azul</b><small>Prévia ilustrativa • geometria simplificada</small></div></div>
        <div class="result-row"><div class="result-icon">▧</div><div><b>Modelo 3D + textura PNG</b><small id="model-format">Geometria Bedrock e atlas de textura</small></div><span class="check">✓</span></div>
        <div class="result-row"><div class="result-icon">⌁</div><div><b>Animação inicial</b><small id="animation-format">Arquivo de animação incluído</small></div><span class="check">✓</span></div>
        <div class="result-row"><div class="result-icon">✓</div><div><b>Validação de arquivos</b><small id="validation-status">Aguardando geração</small></div><span id="validation-icon" class="pending">•</span></div>
      </div>
    </section>
    <section id="output" class="panel output-panel">
      <div class="panel-heading"><div><span class="step">03</span><h2>Exportar e validar</h2></div><span class="tiny-tag">EXPORT</span></div>
      <div class="output-empty" id="output-empty"><div class="empty-icon">⇩</div><b>Seu addon aparecerá aqui</b><p>Gere um projeto para validar os arquivos e baixar o pacote `.mcaddon`.</p></div>
      <div id="output-content" hidden><div class="validation-list" id="validation-list"></div><button id="download" class="primary download">⇩ Baixar .mcaddon</button><button id="download-source" class="secondary">Baixar projeto-fonte (.zip)</button></div>
    </section>
    <footer><span>ADDON AI 3D</span><span>Feito para criadores Bedrock • Projeto inicial gratuito</span></footer>
  </main>
</div>`;

const $ = (s) => document.querySelector(s);
let generatedAddon = null;
let generatedSource = null;
let projectName = 'addon-ai-3d';

document.querySelectorAll('.suggestion').forEach(btn => btn.addEventListener('click', () => {
  $('#description').value = btn.dataset.prompt;
}));
$('#description').addEventListener('input', updatePreview);
function updatePreview() {
  const d = $('#description').value.toLowerCase();
  let name = 'Criatura 3D', color = '#2788ff';
  if (d.includes('drag')) name = 'Dragão';
  else if (d.includes('robô') || d.includes('robo')) { name = 'Robô'; color = '#8b9bab'; }
  else if (d.includes('máquina') || d.includes('maquina')) { name = 'Máquina'; color = '#43c987'; }
  if (d.includes('vermelh')) color = '#ff4c66';
  if (d.includes('verde')) color = '#43c987';
  if (d.includes('roxo') || d.includes('rox')) color = '#a66bff';
  if (d.includes('azul')) color = '#2788ff';
  $('#preview-name').textContent = name;
  $('#model').style.setProperty('--model-color', color);
}
updatePreview();

function uuid() {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => {
    const r = Math.random() * 16 | 0; return (c === 'x' ? r : (r & 3 | 8)).toString(16);
  });
}
function slug(text) {
  return text.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9]+/g,'_').replace(/^_|_$/g,'').slice(0,30) || 'criacao_3d';
}
function infer(text, aiSpec = null) {
  const d = text.toLowerCase();
  let type = $('#kind').value, name = 'Criatura 3D', color = [39,136,255], geometry = 'geometry.addon_ai3d_creature';
  if (d.includes('drag')) { name = 'Dragão'; geometry = 'geometry.addon_ai3d_dragon'; }
  else if (d.includes('robô') || d.includes('robo')) { name = 'Robô Guardião'; color = [130,151,170]; geometry = 'geometry.addon_ai3d_robot'; }
  else if (d.includes('máquina') || d.includes('maquina')) { name = 'Máquina Industrial'; type = 'machine'; color = [57,194,130]; geometry = 'geometry.addon_ai3d_machine'; }
  if (d.includes('vermelh')) color = [235,65,83];
  if (d.includes('verde')) color = [57,194,130];
  if (d.includes('roxo')) color = [159,93,238];
  if (d.includes('azul')) color = [39,136,255];
  if (type === 'machine') { name = name === 'Criatura 3D' ? 'Máquina Decorativa' : name; geometry = 'geometry.addon_ai3d_machine'; }
  if (type === 'item') { name = 'Item Personalizado'; geometry = 'geometry.addon_ai3d_item'; }
  if (aiSpec && typeof aiSpec === 'object') {
    if (typeof aiSpec.name === 'string' && aiSpec.name.trim()) name = aiSpec.name.trim().slice(0,60);
    if (['entity','machine','item'].includes(aiSpec.type)) type = aiSpec.type;
    if (Array.isArray(aiSpec.color) && aiSpec.color.length === 3) color = aiSpec.color.map(v => Math.max(0, Math.min(255, Number(v) || 0)));
    if (type === 'machine') geometry = 'geometry.addon_ai3d_machine';
    else if (type === 'item') geometry = 'geometry.addon_ai3d_item';
    else if (/drag|drac/i.test(name + ' ' + text)) geometry = 'geometry.addon_ai3d_dragon';
    else if (/rob[oô]/i.test(name + ' ' + text)) geometry = 'geometry.addon_ai3d_robot';
  }
  return {type,name,color,geometry,slug:slug(name),aiSpec};
}
function pngTexture(rgb) {
  // PNG 64x64 via Canvas; creates an actual PNG data URL and converts it to bytes.
  const canvas = document.createElement('canvas'); canvas.width = 64; canvas.height = 64;
  const ctx = canvas.getContext('2d');
  ctx.fillStyle = `rgb(${rgb.join(',')})`; ctx.fillRect(0,0,64,64);
  ctx.fillStyle = 'rgba(255,255,255,0.18)';
  for (let y=0;y<64;y+=16) for(let x=0;x<64;x+=16) if ((x+y)%32===0) ctx.fillRect(x,y,16,16);
  ctx.fillStyle = 'rgba(0,0,0,0.12)'; ctx.fillRect(0,48,64,16);
  ctx.fillStyle = '#fff'; ctx.fillRect(8,8,5,5); ctx.fillRect(51,8,5,5);
  return new Promise(resolve => canvas.toBlob(blob => blob.arrayBuffer().then(resolve), 'image/png'));
}
function geometryJson(info) {
  const c = info.color;
  const cube = (origin,size,uv) => ({origin,size,uv});
  let bones = [
    {name:'body',pivot:[0,12,0],cubes:[cube([-4,6,-3],[8,8,6],[0,0])]},
    {name:'head',pivot:[0,17,-2],cubes:[cube([-3,14,-5],[6,6,6],[0,16])]},
    {name:'left_leg',pivot:[-2,7,0],cubes:[cube([-2,0,-2],[3,7,4],[0,32])]},
    {name:'right_leg',pivot:[2,7,0],cubes:[cube([-1,0,-2],[3,7,4],[16,32])]},
    {name:'left_wing',pivot:[-4,13,0],cubes:[cube([-10,0,0],[6,1,7],[32,0])]},
    {name:'right_wing',pivot:[4,13,0],cubes:[cube([4,0,0],[6,1,7],[32,8])]}
  ];
  if (info.geometry.includes('robot')) bones = [
    {name:'body',pivot:[0,12,0],cubes:[cube([-4,5,-3],[8,9,6],[0,0])]},
    {name:'head',pivot:[0,18,0],cubes:[cube([-3,15,-3],[6,6,6],[0,16])]},
    {name:'left_arm',pivot:[-5,15,0],cubes:[cube([-2,-5,-2],[3,8,4],[32,0])]},
    {name:'right_arm',pivot:[5,15,0],cubes:[cube([-1,-5,-2],[3,8,4],[32,16])]},
    {name:'left_leg',pivot:[-2,7,0],cubes:[cube([-2,0,-2],[3,7,4],[0,32])]},
    {name:'right_leg',pivot:[2,7,0],cubes:[cube([-1,0,-2],[3,7,4],[16,32])]}
  ];
  if (info.type === 'machine' || info.type === 'item') bones = [
    {name:'base',pivot:[0,0,0],cubes:[cube([-6,0,-6],[12,8,12],[0,0])]},
    {name:'core',pivot:[0,8,0],cubes:[cube([-4,8,-4],[8,8,8],[0,24])]},
    {name:'antenna',pivot:[0,16,0],cubes:[cube([-1,16,-1],[2,4,2],[32,0])]}
  ];
  return {format_version:'1.12.0', 'minecraft:geometry':[{
    description:{identifier:info.geometry, texture_width:64,texture_height:64,visible_bounds_width:3,visible_bounds_height:3,visible_bounds_offset:[0,1,0]},
    bones
  }]};
}

async function buildJavaScaffold(info, description, platform) {
  const zip = new JSZip();
  const modid = 'addonai3d';
  const pkg = 'com.addonai3d.generated';
  const version = platform === 'Fabric' ? '1.21.1' : '1.21.1';
  const rgb = info.color;
  const canvas = document.createElement('canvas'); canvas.width=64; canvas.height=64;
  const ctx=canvas.getContext('2d'); ctx.fillStyle=`rgb(${rgb.join(',')})`; ctx.fillRect(0,0,64,64);
  ctx.fillStyle='rgba(255,255,255,.18)'; for(let y=0;y<64;y+=16)for(let x=0;x<64;x+=16)if((x+y)%32===0)ctx.fillRect(x,y,16,16);
  const png = await new Promise(resolve=>canvas.toBlob(b=>b.arrayBuffer().then(resolve),'image/png'));
  zip.file('README.md',`# Addon AI 3D — scaffold Java (${platform})\n\nDescrição: ${description}\n\nEste é um esqueleto de projeto, não um mod .jar compilado. Configure versões de Gradle, JDK, Minecraft e ${platform} conforme a documentação oficial antes de compilar.\n`);
  zip.file('settings.gradle',`pluginManagement { repositories { maven { url = 'https://maven.fabricmc.net/' }; gradlePluginPortal(); mavenCentral() } }\ndependencyResolutionManagement { repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS); repositories { mavenCentral() } }\nrootProject.name = 'addon-ai-3d-${info.slug}'\n`);
  if (platform === 'Fabric') {
    zip.file('build.gradle',`plugins { id 'fabric-loom' version '1.9-SNAPSHOT' }\nversion = '0.1.0'\ngroup = 'com.addonai3d'\nbase { archivesName = '${info.slug}' }\nrepositories { mavenCentral() }\ndependencies { minecraft 'com.mojang:minecraft:${version}'; mappings 'net.fabricmc:yarn:${version}+build.3:v2'; modImplementation 'net.fabricmc:fabric-loader:0.16.10'; modImplementation 'net.fabricmc.fabric-api:fabric-api:0.110.0+${version}' }\njava { toolchain { languageVersion = JavaLanguageVersion.of(21) } }\n`);
    zip.file('src/main/resources/fabric.mod.json',JSON.stringify({schemaVersion:1,id:modid,version:'0.1.0',name:`Addon AI 3D - ${info.name}`,description:description,authors:['Addon AI 3D'],environment:'*',entrypoints:{main:[`${pkg}.GeneratedMod`]},depends:{fabricloader:">=0.16.0",minecraft:"~1.21.1","java":">=21"}},null,2));
    zip.file('src/main/java/com/addonai3d/generated/GeneratedMod.java',`package ${pkg};\n\nimport net.fabricmc.api.ModInitializer;\nimport org.slf4j.Logger;\nimport org.slf4j.LoggerFactory;\n\npublic class GeneratedMod implements ModInitializer {\n  public static final String MOD_ID = \"${modid}\";\n  public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);\n  @Override public void onInitialize() {\n    LOGGER.info(\"Addon AI 3D scaffold carregado: ${info.name.replace(/"/g,'')}\");\n    // TODO: registrar blocos, itens e entidades compatíveis com a versão-alvo.\n  }\n}\n`);
  } else {
    zip.file('build.gradle',`plugins { id 'java' }\ngroup = 'com.addonai3d'\nversion = '0.1.0'\njava { toolchain { languageVersion = JavaLanguageVersion.of(21) } }\n// Scaffold neutro NeoForge: adicione o plugin e as dependências oficiais da versão-alvo.\n`);
    zip.file('src/main/java/com/addonai3d/generated/GeneratedMod.java',`package ${pkg};\n\n/** Esqueleto de código para integração com NeoForge. */\npublic final class GeneratedMod {\n  public static final String MOD_ID = \"${modid}\";\n  public static final String DISPLAY_NAME = \"${info.name.replace(/"/g,'')}\";\n  private GeneratedMod() {}\n  // TODO: adicionar @Mod, dependências e registros conforme a versão NeoForge escolhida.\n}\n`);
    zip.file('src/main/resources/META-INF/neoforge.mods.toml',`modLoader=\"javafml\"\nloaderVersion=\"[4,)\"\nlicense=\"MIT\"\n[[mods]]\nmodId=\"${modid}\"\nversion=\"0.1.0\"\ndisplayName=\"Addon AI 3D - ${info.name}\"\ndescription='''${description.replace(/'/g,"")}'''\n`);
  }
  zip.file('src/main/resources/assets/addonai3d/models/item/generated_item.json',JSON.stringify({parent:'minecraft:item/generated',textures:{layer0:`addonai3d:item/${info.slug}`}},null,2));
  zip.file(`src/main/resources/assets/addonai3d/textures/item/${info.slug}.png`,png);
  zip.file('assets/model-reference.json',JSON.stringify(geometryJson(info),null,2));
  zip.file('assets/animation-reference.json',JSON.stringify({note:'Referência de animação; integrar com a biblioteca/sistema de entidades escolhido.',loop:true,bones:['body','head','left_leg','right_leg']},null,2));
  return await zip.generateAsync({type:'blob'});
}

async function buildAddon() {
  const text = $('#description').value.trim();
  if (!text) { alert('Escreva uma descrição antes de gerar.'); return; }
  const btn = $('#generate'); btn.disabled = true; btn.innerHTML = '◌ Gerando arquivos...';
  try {
    let aiSpec = null;
    try {
      const response = await fetch('/.netlify/functions/generate', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({description:text, kind:$('#kind').value, target:$('#target').value})});
      if (response.ok) { const payload = await response.json(); aiSpec = payload.spec || null; }
      else { const payload = await response.json().catch(()=>({})); console.warn('IA indisponível:', payload.error || response.status); }
    } catch (aiError) { console.info('Backend de IA ainda não configurado; usando gerador local.', aiError); }
    const info = infer(text, aiSpec), target = $('#target').value, project = slug(info.name);
    if (target !== 'bedrock') {
      const platform = target === 'java-fabric' ? 'Fabric' : 'NeoForge';
      const javaZip = await buildJavaScaffold(info, text, platform);
      generatedAddon = javaZip;
      generatedSource = javaZip;
      projectName = `addon-ai-3d-${project}-${platform.toLowerCase()}`;
      $('#validation-list').innerHTML = [
        ['Estrutura Java',true,'Projeto Gradle e arquivos-base incluídos'],
        ['Modelo 3D JSON',true,'Modelo de referência incluído'],
        ['Textura PNG',true,'Textura PNG gerada'],
        ['Código do mod',true,'Classe de entrada de exemplo incluída'],
        ['Compilação do .jar',false,'Compile com Gradle usando JDK e dependências compatíveis']
      ].map(([name,ok,desc])=>`<div class="check-row"><span class="${ok?'ok':'warn'}">${ok?'✓':'!'}</span><div><b>${name}</b><small>${desc}</small></div></div>`).join('');
      $('#validation-status').textContent = 'Estrutura Java preparada; compilação pendente';
      $('#validation-icon').textContent = '!'; $('#validation-icon').className='pending';
      $('#output-empty').hidden = true; $('#output-content').hidden = false;
      $('#download').textContent = `⇩ Baixar ${projectName}.zip`;
      $('#download').onclick = () => saveBlob(generatedAddon,`${projectName}.zip`);
      $('#download-source').textContent = 'Baixar projeto-fonte (.zip)';
      $('#download-source').onclick = () => saveBlob(generatedSource,`${projectName}-fonte.zip`);
      $('#model-format').textContent = 'Modelo de referência JSON para projeto Java';
      $('#animation-format').textContent = 'Esqueleto para integração de animação';
      $('#preview-name').textContent = info.name;
      $('#output').scrollIntoView({behavior:'smooth',block:'start'});
      return;
    }
    $('#model-format').textContent = 'Geometria Bedrock e textura PNG';
    $('#animation-format').textContent = 'Arquivo de animação incluído';
    projectName = `addon-ai-3d-${project}`;
    const bpUuid = uuid(), bpModule = uuid(), rpUuid = uuid(), rpModule = uuid();
    const zip = new JSZip();
    const bp = zip.folder('Addon_AI3D_BP'), rp = zip.folder('Addon_AI3D_RP');
    bp.file('manifest.json', JSON.stringify({format_version:2,header:{name:`Addon AI 3D BP - ${info.name}`,description:'Gerado pelo Addon AI 3D (MVP)',uuid:bpUuid,version:[1,0,0],min_engine_version:[1,20,0]},modules:[{type:'data',uuid:bpModule,version:[1,0,0]}],dependencies:[{uuid:rpUuid,version:[1,0,0]}]},null,2));
    rp.file('manifest.json', JSON.stringify({format_version:2,header:{name:`Addon AI 3D RP - ${info.name}`,description:'Modelos e texturas gerados pelo Addon AI 3D',uuid:rpUuid,version:[1,0,0],min_engine_version:[1,20,0]},modules:[{type:'resources',uuid:rpModule,version:[1,0,0]}]},null,2));
    const entityId = `addon_ai3d:${project}`;
    const entity = {format_version:'1.20.0', 'minecraft:entity':{description:{identifier:entityId,is_spawnable:true,is_summonable:true,is_experimental:false,properties:{}},components:{'minecraft:type_family':{family:['addon_ai3d','mob']},'minecraft:health':{value:20,max:20},'minecraft:movement':{value:0.25},'minecraft:collision_box':{width:1.2,height:2},'minecraft:physics':{},'minecraft:pushable':{is_pushable:true,is_pushable_by_piston:true},'minecraft:movement.basic':{},'minecraft:navigation.walk':{can_path_over_water:true},'minecraft:behavior.random_stroll':{priority:6,speed_multiplier:1},'minecraft:behavior.look_at_player':{priority:7,look_distance:6},'minecraft:behavior.random_look_around':{priority:8},'minecraft:loot':{table:'loot_tables/entities/default.json'}}}};
    if (info.type !== 'item') bp.file(`entities/${project}.json`,JSON.stringify(entity,null,2));
    bp.file('loot_tables/entities/default.json',JSON.stringify({pools:[{rolls:1,entries:[{type:'item',name:'minecraft:air',weight:1}]}]},null,2));
    rp.file('entity/'+project+'.entity.json',JSON.stringify({format_version:'1.10.0','minecraft:client_entity':{description:{identifier:entityId,materials:{default:'entity_alphatest'},textures:{default:`textures/entity/${project}`},geometry:{default:info.geometry},animations:{move:'animation.addon_ai3d.move'},scripts:{animate:['move']},render_controllers:['controller.render.default']}}},null,2));
    rp.file('models/entity/'+project+'.geo.json',JSON.stringify(geometryJson(info),null,2));
    rp.file('animations/'+project+'.animation.json',JSON.stringify({format_version:'1.8.0',animations:{'animation.addon_ai3d.move':{loop:true,animation_length:2,bones:{left_leg:{rotation:['math.sin(query.anim_time * 360) * 20',0,0]},right_leg:{rotation:['math.sin(query.anim_time * 360 + 180) * 20',0,0]},left_wing:{rotation:[0,0,'math.sin(query.anim_time * 180) * 25']},right_wing:{rotation:[0,0,'-math.sin(query.anim_time * 180) * 25']}}}}},null,2));
    rp.file('render_controllers/controller.render.default.json',JSON.stringify({'format_version':'1.8.0','render_controllers':{'controller.render.default':{geometry:'Geometry.default',materials:[{ '*':'Material.default'}],textures:['Texture.default']}}},null,2));
    const texture = await pngTexture(info.color);
    rp.file(`textures/entity/${project}.png`,texture);
    rp.file('texts/languages.json',JSON.stringify(['en_US','pt_BR']));
    rp.file('texts/pt_BR.lang',`entity.${entityId}.name=${info.name}\n`);
    rp.file('texts/en_US.lang',`entity.${entityId}.name=${info.name}\n`);
    rp.file('textures/item_texture.json',JSON.stringify({resource_pack_name:'Addon_AI3D',texture_name:'atlas.items',texture_data:{}},null,2));
    // Source notes and generation metadata
    zip.file('LEIA-ME.txt',`Addon criado com Addon AI 3D MVP\nNome: ${info.name}\nDescrição original: ${text}\nAlvo selecionado: Bedrock ${target} (modelo de arquivos inicial)\nID: ${entityId}\nImporte o .mcaddon no Minecraft e teste em um mundo de cópia com os pacotes ativados.\nEste gerador usa regras simples, não uma API de IA externa.`);
    const addonBlob = await zip.generateAsync({type:'blob'});
    generatedAddon = addonBlob;
    const sourceZip = new JSZip();
    sourceZip.file('prompt.txt',text);
    sourceZip.file('metadata.json',JSON.stringify({name:info.name,description:text,target,entityId,geometry:info.geometry,color:info.color,aiEnhanced:Boolean(aiSpec),aiSpec,generatedAt:new Date().toISOString()},null,2));
    sourceZip.file('geometry.json',JSON.stringify(geometryJson(info),null,2));
    sourceZip.file('LEIA-ME.md','Projeto-fonte de geração Addon AI 3D. O pacote .mcaddon contém BP e RP completos para o modelo inicial.');
    generatedSource = await sourceZip.generateAsync({type:'blob'});
    const checks = [
      ['Manifestos BP e RP', true, 'Dois manifestos com UUIDs distintos incluídos'],
      ['Geometria 3D JSON', true, 'Arquivo de geometria incluído'],
      ['Textura PNG', texture.byteLength > 50, `${texture.byteLength} bytes gerados`],
      ['Animação', true, 'Arquivo de animação incluído'],
      ['Referências', true, 'IDs de entidade e geometria conectados no RP'],
      ['Compatibilidade no jogo', false, 'Requer teste dentro da versão selecionada do Minecraft']
    ];
    $('#validation-list').innerHTML = checks.map(([name,ok,desc])=>`<div class="check-row"><span class="${ok?'ok':'warn'}">${ok?'✓':'!'}</span><div><b>${name}</b><small>${desc}</small></div></div>`).join('');
    $('#validation-status').textContent = 'Verificações estruturais concluídas';
    $('#validation-icon').textContent = '✓'; $('#validation-icon').className='check';
    $('#output-empty').hidden = true; $('#output-content').hidden = false;
    $('#download').textContent = `⇩ Baixar ${projectName}.mcaddon`;
    $('#download').onclick = () => saveBlob(generatedAddon,`${projectName}.mcaddon`);
    $('#download-source').onclick = () => saveBlob(generatedSource,`${projectName}-fonte.zip`);
    $('#model').style.setProperty('--model-color',`rgb(${info.color.join(',')})`);
    $('#preview-name').textContent = info.name;
    $('#output').scrollIntoView({behavior:'smooth',block:'start'});
  } catch (e) {
    console.error(e); alert('Não foi possível gerar os arquivos: '+e.message);
  } finally { btn.disabled=false; btn.innerHTML='<span>✧</span> Gerar addon'; }
}
function saveBlob(blob, filename) {
  const url = URL.createObjectURL(blob), a = document.createElement('a');
  a.href=url; a.download=filename; document.body.appendChild(a); a.click(); a.remove();
  setTimeout(()=>URL.revokeObjectURL(url),1500);
}
$('#generate').addEventListener('click',buildAddon);
