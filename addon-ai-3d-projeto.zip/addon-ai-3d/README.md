# Addon AI 3D — site + base Android

Projeto responsivo para planejar e criar pacotes Minecraft por descrição, com exportação Bedrock `.mcaddon` e scaffolds Java Fabric/NeoForge em `.zip`.

## IA conectada
O projeto agora inclui uma função serverless em `netlify/functions/generate.mjs` que chama a API OpenAI para interpretar a ideia e sugerir nome, tipo, cor, partes do modelo, textura e animação. Para ativar:

1. Publique este repositório/pasta no Netlify.
2. No painel do site, abra **Site configuration → Environment variables** (ou a área equivalente) e crie `OPENAI_API_KEY` com uma chave de API válida.
3. Opcionalmente, defina `OPENAI_MODEL` (padrão `gpt-4.1-mini`) e faça novo deploy.
4. Gere um addon e confira os arquivos antes de importar no Minecraft.

**Não coloque a chave da API em `src/main.js` nem em arquivos públicos.** A chamada passa pelo backend do Netlify. O uso da API pode gerar custos conforme a conta/provedor; hospedagem gratuita não significa API de IA gratuita.

Se a função não estiver publicada ou a chave não estiver configurada, a interface usa o gerador local por regras, sem IA generativa.

## Executar localmente
```bash
npm install
npm run dev
```
Para testar a função serverless localmente, instale a CLI do Netlify e use `netlify dev` após configurar `OPENAI_API_KEY` no ambiente.

## Preparar Android
```bash
npm install
npm run build
npx cap add android
npx cap sync android
npx cap open android
```
Compile no Android Studio. Este ZIP contém o código-fonte, não um APK compilado.

## O que gera
- Bedrock: estrutura BP/RP, geometria JSON simplificada, PNG, animação e pacote `.mcaddon` inicial.
- Java Fabric/NeoForge: scaffolds ZIP e recursos de referência, não um `.jar` compilado.
- IA: interpretação da ideia e especificação de design; não gera automaticamente um modelo 3D complexo profissional, nem garante compatibilidade no jogo.

Teste sempre em um mundo de cópia. A validação atual é estrutural e não substitui testes dentro da versão exata do Minecraft.
