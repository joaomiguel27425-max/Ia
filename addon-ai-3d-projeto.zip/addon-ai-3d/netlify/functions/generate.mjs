export default async (request) => {
  if (request.method !== 'POST') return Response.json({ error: 'Use POST.' }, { status: 405 });
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) return Response.json({ error: 'OPENAI_API_KEY não configurada no servidor.' }, { status: 503 });
  try {
    const body = await request.json();
    const description = String(body.description || '').trim().slice(0, 4000);
    const kind = ['entity', 'machine', 'item'].includes(body.kind) ? body.kind : 'entity';
    const target = ['bedrock', 'java-fabric', 'java-neoforge'].includes(body.target) ? body.target : 'bedrock';
    if (!description) return Response.json({ error: 'Escreva uma descrição.' }, { status: 400 });
    const upstream = await fetch('https://api.openai.com/v1/responses', {
      method: 'POST',
      headers: { Authorization: `Bearer ${apiKey}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: process.env.OPENAI_MODEL || 'gpt-4.1-mini',
        instructions: 'Você é o planejador técnico do Addon AI 3D para Minecraft. Responda somente JSON válido com as chaves name (nome curto em português), type (entity, machine ou item), color (array RGB de três inteiros 0-255), parts (array de até 8 nomes curtos de partes 3D), textureNotes (string em português), animationNotes (string em português), behaviorNotes (string em português). Não afirme que arquivos foram compilados ou testados. Escolha type compatível com a solicitação. Nunca inclua markdown.',
        input: `Plataforma: ${target}\nTipo escolhido: ${kind}\nIdeia do usuário: ${description}`,
        text: { format: { type: 'json_object' } }
      })
    });
    const data = await upstream.json();
    if (!upstream.ok) return Response.json({ error: data?.error?.message || 'Falha no provedor de IA.' }, { status: 502 });
    const outputText = data.output?.flatMap(item => item.content || []).find(item => item.type === 'output_text')?.text;
    if (!outputText) return Response.json({ error: 'A IA não retornou uma especificação.' }, { status: 502 });
    const spec = JSON.parse(outputText);
    return Response.json({ spec }, { headers: { 'Cache-Control': 'no-store' } });
  } catch (error) {
    return Response.json({ error: 'Não foi possível processar a solicitação da IA.' }, { status: 500 });
  }
};
